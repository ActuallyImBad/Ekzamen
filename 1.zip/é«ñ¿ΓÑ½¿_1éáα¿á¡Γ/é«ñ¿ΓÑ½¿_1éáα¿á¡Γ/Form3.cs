﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Водители_1Вариант
{
    public partial class Form3 : Form
    {
        public Model1 db = new Model1();
        
        public Form3()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (nameTextBox.Text == "" || middlenameTextBox.Text == "" || patronymicTextBox.Text == "" || ссерия_и_номер_паспортаTextBox.Text == "" || addressTextBox.Text == "" || address_lifeTextBox.Text == "" || jobnameTextBox.Text == "" || phoneTextBox.Text == "" || emailTextBox.Text == "")
            {
                MessageBox.Show("Нужно ввести все требуемые данные");
                return;
            }
            Drivers drivers = new Drivers();
            drivers.ID = iDTextBox.Text;
            drivers.middlename = middlenameTextBox.Text;
            drivers.name = nameTextBox.Text;
            drivers.patronymic = patronymicTextBox.Text;
            drivers.Ссерия_и_номер_паспорта = ссерия_и_номер_паспортаTextBox.Text;
            drivers.address = addressTextBox.Text;
            drivers.address_life = address_lifeTextBox.Text;
            drivers.jobname = jobnameTextBox.Text;
            drivers.phone = phoneTextBox.Text;
            drivers.email = emailTextBox.Text;
            drivers.decription = decriptionTextBox.Text;
            db.Drivers.Add(drivers);
            Update();
            try
            {
                db.SaveChanges();
                DialogResult = DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

       

        private void Form3_Load(object sender, EventArgs e)
        {
           


        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 db = new Form2();
            db.Show();
            this.Hide();
        }

        private void iDTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void middlenameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void patronymicTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void ссерия_и_номер_паспортаTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void addressTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void address_lifeTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void jobnameTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void phoneTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void emailTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void nameTextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
