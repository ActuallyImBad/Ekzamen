﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Водители_1Вариант
{
    public partial class Form2 : Form
    {
        
        Model1 db = new Model1();
        public Form2()
        {
            InitializeComponent();
        }
        public static Drivers drive { get; set; } = null;

        private void driversBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.driversBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.driversDataSet);

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "driversDataSet.Drivers". При необходимости она может быть перемещена или удалена.
            this.driversTableAdapter.Fill(this.driversDataSet.Drivers);
            driversBindingSource.DataSource = db.Drivers.ToList();
           if (drive ==null)
            {
                driversBindingSource.AddNew();
            }
           else
            {
                driversBindingSource.Add(drive);
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form3 frm3 = new Form3();
            frm3.db = db;
            DialogResult dri = frm3.ShowDialog();
            if (dri == DialogResult.OK)
            {
                driversBindingSource.DataSource = db.Drivers.ToList();
            }
            this.Hide();
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Drivers drive = (Drivers)driversBindingSource.Current;
            DialogResult dri = MessageBox.Show("Удалить учётную запись"+drive.ID+"?", "Удаление учётной записи", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dri == DialogResult.Yes)
            {
                db.Drivers.Remove(drive);
                Update();
            }
            try
            {
                db.SaveChanges();
                MessageBox.Show("Успешное сохранение");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            driversBindingSource.DataSource = db.Drivers.Where(a => a.name.Contains(textBox1.Text) || a.middlename.Contains(textBox1.Text)).ToList();
        }

       
        private void driversBindingSource_CurrentChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Drivers drv = (Drivers)driversBindingSource.Current;
            Form4 frm4 = new Form4();
            frm4.drivers = drv;
            DialogResult dr = frm4.ShowDialog();
            if (dr == DialogResult.OK)
            {
                driversBindingSource.DataSource = null;
                driversBindingSource.DataSource = db.Drivers.ToList();
            }
            this.Hide();

        }
    }
}
