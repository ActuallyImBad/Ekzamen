﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Водители_1Вариант
{
    public partial class Form1 : Form
    {
        Model1 db = new Model1();
        public Form1()
        {
            InitializeComponent();
        }
       int Chetchik=0;

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Chetchik++;
            if (textBox1.Text=="inspector" || textBox2.Text=="inspector") //Проверка логина и пароля
            {
                Form2 db =new Form2();
                this.Hide();
                db.Show();
            }
            else if (Chetchik>=3)
            {
                textBox1.Enabled = false; // Блокировка строку ввода логина
                textBox2.Enabled = false; // Блокировка строку ввода пароля
                MessageBox.Show("Превышен лимит попыток захода в систему, пожалуйста перезапустите систему и повторите вход");
            }
            if (textBox1.Text != "inspector" || textBox2.Text != "inspector") // Если пользователь вводит неверный логин или пароль
            {
                MessageBox.Show("Неверный логин и пароль");
                return;
            }
            else if (Chetchik >= 3) // лимит до 3 попыток
            {
                textBox1.Enabled = false; //блокируем строку ввода логина
                textBox2.Enabled = false; //блокируем строку ввода пароля
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
